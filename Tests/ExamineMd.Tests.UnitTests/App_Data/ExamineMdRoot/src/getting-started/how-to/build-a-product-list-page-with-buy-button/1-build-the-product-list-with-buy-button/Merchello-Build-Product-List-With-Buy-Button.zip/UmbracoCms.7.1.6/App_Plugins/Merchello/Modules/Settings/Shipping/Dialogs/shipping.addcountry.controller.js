﻿(function (controllers, undefined) {

    /**
     * @ngdoc controller
     * @name Merchello.Dashboards.Settings.Shipping.Dialogs.ShippingAddCountryController
     * @function
     * 
     * @description
     * The controller for adding a country
     */
	controllers.ShippingAddCountryController = function ($scope) {

    };

	angular.module("umbraco").controller("Merchello.Dashboards.Settings.Shipping.Dialogs.ShippingAddCountryController", ['$scope', merchello.Controllers.ShippingAddCountryController]);


}(window.merchello.Controllers = window.merchello.Controllers || {}));
