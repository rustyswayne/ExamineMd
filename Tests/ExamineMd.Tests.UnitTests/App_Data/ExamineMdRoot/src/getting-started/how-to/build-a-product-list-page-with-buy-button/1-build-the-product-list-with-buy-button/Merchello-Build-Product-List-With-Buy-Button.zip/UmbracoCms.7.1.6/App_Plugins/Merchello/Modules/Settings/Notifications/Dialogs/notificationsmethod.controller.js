﻿(function (controllers, undefined) {

    /**
     * @ngdoc controller
     * @name Merchello.Dashboards.Settings.Notifications.Dialogs.NotificationsMethodController
     * @function
     * 
     * @description
     * The controller for the adding / editing Notification methods on the Notifications page
     */
    controllers.NotificationsMethodController = function ($scope) {


    };

    angular.module("umbraco").controller("Merchello.Dashboards.Settings.Notifications.Dialogs.NotificationsMethodController", ['$scope', merchello.Controllers.NotificationsMethodController]);


}(window.merchello.Controllers = window.merchello.Controllers || {}));
