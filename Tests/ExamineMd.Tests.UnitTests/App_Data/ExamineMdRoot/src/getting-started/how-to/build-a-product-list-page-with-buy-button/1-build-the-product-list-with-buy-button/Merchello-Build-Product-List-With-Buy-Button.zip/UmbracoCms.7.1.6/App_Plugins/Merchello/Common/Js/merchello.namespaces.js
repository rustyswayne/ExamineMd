﻿
(function (merchello, undefined) {

    // Global namespaces defined
    merchello.Models = {};
    merchello.Controllers = {};
    merchello.Directives = {};
    merchello.Filters = {};
    merchello.Services = {};
    merchello.Helpers = {};

}(window.merchello = window.merchello || {}));